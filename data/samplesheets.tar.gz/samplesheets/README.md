Contains samplesheets used to test the valid_samplesheet and no_disallowed_sserrs function in demultiplex.py

# TODO add description of what is right / wrong with each test case